<?php
	
	$con=mysqli_connect('localhost','admin','admin','smartcity');

?>